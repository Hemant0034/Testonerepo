package BuyerTest.Base;

import org.testng.annotations.Test;
import org.openqa.selenium.chrome.*;

import java.io.ObjectInputFilter.Config;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;
//import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;


@Test
public class BaseTest {
	

    public WebDriver driver;
    public Config config;
    public ExtentReports extent;
    public ExtentTest test;
    public ExtentReports reportsinhtml;
    
    @BeforeSuite
    public void intiateReport()
    {
    	reportsinhtml = new ExtentReports() ;
    	ExtentReports extent = new ExtentReports();
//    	String filename = currentDateTime();
//    	ExtentSparkReporter spark = new ExtentSparkReporter("Reports/" + filename +".html");
//      Illegal char <:> at index 21: Reports\2024\01\07 04:06:37.html
    	ExtentSparkReporter spark = new ExtentSparkReporter("Reports/Spark.html");
    	extent.attachReporter(spark);
    	spark.config().getTheme();
    	extent.setSystemInfo("os", "macos");
    	extent.setSystemInfo("Environment", "UAT");
    	extent.setSystemInfo("TestSuit", "TS1");
    	extent.createTest("Test Logged In Functionality")
    	  .log(Status.PASS, "This is a logging event for Government E Marketplace!");
    	extent.flush();
    	}
    
    
    
    
//	private String currentDateTime() {
//		   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
//		   LocalDateTime now = LocalDateTime.now();  
//		   return dtf.format(now);
//	}




	public void test()
	{
	String url ="https://uat.gemorion.org/";
	System.setProperty("webdriver.chrome.driver","D:\\Driver\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get(url);
	driver.manage().window().maximize();
	System.out.println("Hello");
	
	
	}

}
